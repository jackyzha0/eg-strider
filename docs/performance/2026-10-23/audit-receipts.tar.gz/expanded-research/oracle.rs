
use compare::Trace;
use diamond_types::list::ListOpLog;
fn main() {
    for path in std::env::args().skip(1) {
        let raw = std::fs::read(&path).unwrap();
        let trace = Trace::of_json(&raw).unwrap();
        let h = trace.history;
        let mut dt = ListOpLog::new();
        let agents: Vec<_> = h.agents.iter().map(|n| dt.get_or_create_agent_id(n)).collect();
        for t in &h.txns {
            dt.add_operations_remote(agents[t.agent], h.parents(t), t.sequence_number, h.ops(t));
        }
        let expected = dt.checkout_tip().content().to_string();
        let mut value: serde_json::Value = serde_json::from_slice(&raw).unwrap();
        value["endContent"] = serde_json::Value::String(expected);
        std::fs::write(&path, serde_json::to_vec(&value).unwrap()).unwrap();
        println!("{} {} events", path, dt.len());
    }
}
