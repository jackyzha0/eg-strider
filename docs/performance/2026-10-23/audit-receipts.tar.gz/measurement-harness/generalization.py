#!/usr/bin/env python3
"""Measure existing candidates on additional, fully shared research workloads."""
import hashlib
import json
import os
from pathlib import Path
import random
import secrets
import subprocess
import time

import evaluator
from prepare import save
from registry import STATE
from source import digest


def history(seed, alphabet, width, replicas, rounds, branch_steps, delete_rate, batch, position):
    rng = random.Random(seed)
    txns = []
    children = []
    def add(parents, agent, patches):
        index = len(txns)
        for parent in parents:
            children[parent] += 1
        txns.append(dict(parents=parents, numChildren=0, agent=agent, patches=patches))
        children.append(0)
        return index
    def text(length):
        return ''.join(rng.choice(alphabet) for _ in range(length))
    # An abstract per-round base index identifies overlap between replicas'
    # deletions. Insertions made on another branch are not visible to a replica.
    length = 256
    base = add([], 0, [[0, 0, text(length)]])
    for round_index in range(rounds):
        tips, deleted, inserted = [], set(), 0
        for who in range(replicas):
            local = list(range(length))
            parent = base
            for step in range(branch_steps):
                patches = []
                for _ in range(batch):
                    erase = bool(local) and rng.random() < delete_rate
                    if erase:
                        if position == 'tail':
                            count = min(len(local), rng.randint(1, max(1, width)))
                            at = len(local) - count
                        else:
                            at = rng.randrange(len(local))
                            count = min(len(local) - at, rng.randint(1, max(1, width)))
                        deleted.update(x for x in local[at:at+count] if x >= 0)
                        del local[at:at+count]
                        patches.append([at, count, ''])
                    else:
                        if position == 'tail':
                            at = len(local)
                        elif position == 'hotspot':
                            at = min(len(local), rng.randrange(17))
                        elif position == 'apart':
                            at = min(len(local), len(local)*(2*who+1)//(2*replicas))
                        else:
                            at = rng.randrange(len(local)+1)
                        payload = text(rng.randint(1, width))
                        # Distinct negative identities are unnecessary: only base
                        # identities can overlap across the concurrent branches.
                        local[at:at] = [-1] * len(payload)
                        patches.append([at, 0, payload])
                parent = add([parent], who, patches)
            inserted += sum(x < 0 for x in local)
            tips.append(parent)
        length = length - len(deleted) + inserted
        # Every branch's visible position is valid. The join insertion is at
        # zero, valid independently of concurrent tie-breaking rules.
        base = add(tips, 0, [[0, 0, text(1)]])
        length += 1
    for txn, count in zip(txns, children):
        txn['numChildren'] = count
    return dict(kind='concurrent' if replicas > 1 else 'sequential',
                numAgents=replicas, txns=txns, endContent='')


ORACLE = r'''
use compare::Trace;
use diamond_types::list::ListOpLog;
fn main() {
    for path in std::env::args().skip(1) {
        let raw = std::fs::read(&path).unwrap();
        let trace = Trace::of_json(&raw).unwrap();
        let h = trace.history;
        let mut dt = ListOpLog::new();
        let agents: Vec<_> = h.agents.iter().map(|n| dt.get_or_create_agent_id(n)).collect();
        for t in &h.txns {
            dt.add_operations_remote(agents[t.agent], h.parents(t), t.sequence_number, h.ops(t));
        }
        let expected = dt.checkout_tip().content().to_string();
        let mut value: serde_json::Value = serde_json::from_slice(&raw).unwrap();
        value["endContent"] = serde_json::Value::String(expected);
        std::fs::write(&path, serde_json::to_vec(&value).unwrap()).unwrap();
        println!("{} {} events", path, dt.len());
    }
}
'''


def oracle(traces, out):
    (out / 'oracle.rs').write_text(ORACLE)
    deps = STATE / 'baseline-target/release/deps'
    args = ['/rust/bin/rustc', '--edition=2021', '-O', '/output/oracle.rs',
            '-L', 'dependency=/target/release/deps', '-o', '/output/oracle']
    for name in ['compare', 'diamond_types', 'serde_json']:
        paths = sorted(deps.glob('lib' + name + '-*.rlib'))
        if len(paths) != 1:
            raise RuntimeError(f'Expected one pinned library for {name}, found {len(paths)}')
        args += ['--extern', name + '=/target/release/deps/' + paths[0].name]
    prefix = ['docker', 'run', '--rm', '--network', 'none', '--cpuset-cpus', '6,22',
        '--user', f'{os.getuid()}:{os.getgid()}', '--read-only', '--cap-drop', 'ALL',
        '--tmpfs', '/tmp:rw,size=256m,mode=1777', '-v', f'{evaluator.RUST}:/rust:ro',
        '-v', f'{STATE / "baseline-target"}:/target:ro', '-v', f'{out}:/output',
        '-v', f'{traces}:/traces', '-e', 'PATH=/rust/bin:/usr/local/bin:/usr/bin:/bin', evaluator.IMAGE]
    with evaluator.core_lease(6):
        evaluator.run_logged(prefix + args, out / 'oracle-build.log')
        evaluator.run_logged(prefix + ['/output/oracle'] + ['/traces/' + p.name for p in sorted(traces.glob('*.json'))], out / 'oracle.log')


def main():
    root = Path(json.loads((STATE / 'current.json').read_text())['root'])
    out = root / 'generalization' / time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
    out.mkdir(parents=True)
    candidates = ['188740618cbc43f398c2df673bd1a4d6',
                  '244a7de89e104457bf345cfd20923547',
                  '899d52bf478f4c9c8d3b2d461c5292d1']
    frozen = []
    for sid in candidates:
        folder = root / 'submissions' / sid
        source = json.loads((folder / 'source.json').read_text())
        binary = folder / 'judge/candidate-benchmark'
        frozen.append(dict(id=sid, source_sha256=digest(source),
                           binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    seed = secrets.randbits(64)
    save(out / 'frozen.json', dict(frozen_unix=time.time(), candidates=frozen,
         seed=seed, primary_candidate=candidates[0],
         protocol='additional fully shared synthetic workloads; unchanged benchmark; 100 runs; ABBA; 5% reference drift; no hidden test set'))
    save(STATE / 'generalization-current.json', {'root': str(out)})
    traces = out / 'traces';traces.mkdir()
    specs = []
    for alphabet_name, alphabet in [('ascii','abcdefghijklmnopqrstuvwxyz '), ('unicode','aé中🙂🧑\u200d🚀\u0301')]:
        specs += [
            (alphabet_name+'-tail-tiny',alphabet,1,1,30,200,.30,1,'tail'),
            (alphabet_name+'-tail-batched',alphabet,8,1,20,100,.35,8,'tail'),
            (alphabet_name+'-random-short',alphabet,4,1,30,200,.45,1,'random'),
            (alphabet_name+'-random-large',alphabet,128,1,12,100,.50,4,'random'),
            (alphabet_name+'-concurrent-apart',alphabet,4,4,30,60,.30,1,'apart'),
            (alphabet_name+'-concurrent-hotspot',alphabet,4,4,30,60,.35,1,'hotspot'),
            (alphabet_name+'-long-branches',alphabet,8,8,8,180,.40,1,'random'),
            (alphabet_name+'-many-replicas',alphabet,4,16,16,30,.35,1,'random'),
            (alphabet_name+'-batched-concurrent',alphabet,32,4,15,40,.50,6,'random'),
            (alphabet_name+'-delete-heavy',alphabet,8,4,24,60,.75,2,'random'),
        ]
    save(out / 'status.json', {'state': 'generating', 'cases': len(specs)})
    for index,(name,*settings) in enumerate(specs):
        save(traces / (name+'.json'), history(seed+index,*settings))
    oracle(traces,out)
    save(out / 'suite.json', {'cases': [dict(name=p.stem,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(traces.glob('*.json'))]})
    for candidate in frozen:
        sid = candidate['id']; folder = out / sid;folder.mkdir()
        binary = root / 'submissions' / sid / 'judge/candidate-benchmark'
        for attempt in range(1,4):
            runs = {}
            with evaluator.core_lease(6) as cpu:
                for label, executable in [('baseline',STATE/'baseline-target/release/compare'),('candidate',binary),('candidate-repeat',binary),('baseline-repeat',STATE/'baseline-target/release/compare')]:
                    save(out/'status.json',dict(state='measuring',candidate=sid,stage=label,attempt=attempt,cpu=cpu,cases=len(specs),reps=100))
                    runs[label] = evaluator.benchmark(executable,folder,f'attempt-{attempt}-{label}',100,cpu,traces=traces)
            first = evaluator.compare_rows(runs['baseline'],runs['candidate'])
            repeat = evaluator.compare_rows(runs['baseline-repeat'],runs['candidate-repeat'])
            controls = [evaluator.control_check(runs['baseline'],runs['candidate'],.05),evaluator.control_check(runs['baseline-repeat'],runs['candidate-repeat'],.05)]
            result = dict(candidate=candidate,first=first,repeat=repeat,controls=controls,
                          valid=all(c['passed'] for c in controls),cases=len(specs),reps=100)
            save(folder/f'result-attempt-{attempt}.json',result)
            if result['valid']:
                save(folder/'result.json',result)
                break
        if not result['valid']:
            save(folder/'result.json',result)
        if hashlib.sha256(binary.read_bytes()).hexdigest()!=candidate['binary_sha256']:
            raise RuntimeError('Frozen executable changed')
    save(out/'status.json',dict(state='complete',finished_unix=time.time(),cases=len(specs)))
    print('COMPLETE '+str(out),flush=True)


if __name__=='__main__':
    main()
