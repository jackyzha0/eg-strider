from pathlib import Path

STATE = Path('/home/vkmr/eg-strider-lab')
TASK = 'eg-strider'
ROOTS = ['crates/eg-strider/src', 'crates/strider-graph/src',
         'crates/strider-text/src', 'crates/strider-tree/src']


def policy(task=TASK):
    if task != TASK:
        raise ValueError('unknown_task')
    return dict(source_root='/workspace', source_roots=ROOTS,
                allowed_extensions=['.rs'], protected_paths=[],
                max_source_bytes=16 * 1024**2, max_source_files=1000)
