"""Replay immutable production sources through Jack's unchanged tests and benchmark."""
import fcntl
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import threading
import time

from prepare import save
from registry import STATE, policy
from source import apply, digest

PRISTINE = Path('/home/vkmr/eg-strider')
IMAGE = 'optimbench-v2:parse5-html-roundtrip-c0947d988461'
RUST = Path('/home/vkmr/optimbench-devtools-next-20261013/ruff/toolchains/rust-1.99.0')
TRACES = STATE / 'egwalker-paper/datasets'
ORIGINAL = None
TIMING_LOCK = threading.Lock()
TIMING_CPUS = list(range(8))
BUILD_CPUS = [f'{cpu},{cpu + 16}' for cpu in TIMING_CPUS]
BUILD_LOCK = threading.Semaphore(len(TIMING_CPUS))
LANE_LOCKS = [threading.Lock() for _ in TIMING_CPUS]


class Rejected(Exception):
    pass


class TimingUnstable(Exception):
    pass


@contextmanager
def core_lease(lane):
    index = lane % len(TIMING_CPUS)
    cpu = TIMING_CPUS[index]
    # A build and a benchmark share a lane's physical core. The lock also
    # excludes independent verification processes from either stage.
    with LANE_LOCKS[index], (STATE / f'timing-{cpu}.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        yield cpu


def copytree(src, dst):
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['cp', '-a', '--reflink=auto', str(src), str(dst)], check=True)


def container_args(project, target, cargo, output, cpus='4,6,20,22', network='none'):
    output.mkdir(parents=True, exist_ok=True)
    return ['docker', 'run', '--rm', '--network', network,
            '--user', f'{os.getuid()}:{os.getgid()}',
            '--cpuset-cpus', cpus, '--memory', '12g', '--memory-swap', '12g',
            '--pids-limit', '512', '--cap-drop', 'ALL',
            '--security-opt', 'no-new-privileges', '--read-only',
            '--tmpfs', '/tmp:rw,exec,size=512m,mode=1777',
            '-v', f'{project}:/workspace:ro', '-v', f'{target}:/target',
            '-v', f'{cargo}:/cargo', '-v', f'{RUST}:/rust:ro',
            '-v', f'{TRACES}:/traces:ro', '-v', f'{output}:/output',
            '-e', 'HOME=/tmp', '-e', 'CARGO_HOME=/cargo',
            '-e', 'CARGO_TARGET_DIR=/target', '-e', 'CARGO_NET_OFFLINE=true',
            '-e', 'PATH=/rust/bin:/usr/local/bin:/usr/bin:/bin',
            '-w', '/workspace', IMAGE]


def run_logged(args, path, timeout=1800):
    start = time.time()
    with Path(path).open('w') as out:
        process = subprocess.run(args, stdout=out, stderr=subprocess.STDOUT, timeout=timeout)
    if process.returncode:
        raise Rejected(f'{Path(path).name}: exit {process.returncode}; ' + Path(path).read_text()[-1800:])
    save(Path(path).with_suffix('.success.json'), {'returncode': 0, 'finished_unix': time.time()})
    return time.time() - start


def benchmark(binary, output, label, reps=15, cpu=7, traces=None):
    output = Path(output)
    traces = Path(traces) if traces is not None else TRACES
    paths = sorted(traces.glob('*.json'))
    if not paths:
        raise Rejected('empty_trace_suite')
    destination = output / f'{label}.json'
    args = ['docker', 'run', '--rm', '--network', 'none', '--cpuset-cpus', str(cpu),
            '--user', f'{os.getuid()}:{os.getgid()}', '--memory', '8g',
            '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--read-only',
            '--tmpfs', '/tmp:rw,size=256m,mode=1777', '-v', f'{binary}:/benchmark:ro',
            '-v', f'{traces}:/traces:ro', '-v', f'{output}:/output',
            '-w', '/tmp', IMAGE, 'python3', '-c',
            'import subprocess,resource,time,json,sys; t=time.perf_counter(); '
            'p=subprocess.run(sys.argv[2:]); u=resource.getrusage(resource.RUSAGE_CHILDREN); '
            'open(sys.argv[1],"w").write(json.dumps(dict(wall_seconds=time.perf_counter()-t,'
            'user_seconds=u.ru_utime,system_seconds=u.ru_stime,returncode=p.returncode))); '
            'sys.exit(p.returncode)', '/output/' + label + '-execution.json',
            '/benchmark', '--reps', str(reps),
            '--without', 'yrs', '--without', 'loro', '--without', 'automerge',
            '--json', '/output/' + destination.name]
    args += ['/traces/' + p.name for p in paths]
    run_logged(args, output / f'{label}.log', timeout=900)
    rows = json.loads(destination.read_text())
    if len(rows) != len(paths) or not all(r['same']['strider'] and r['same']['dt'] for r in rows):
        raise Rejected('trace_oracle_mismatch')
    return rows


def control_check(baseline, candidate, limit=.10):
    other = {r['trace']: r for r in baseline}
    ratios = {r['trace']: other[r['trace']]['merge_ms']['dt'] / r['merge_ms']['dt'] for r in candidate}
    return {'passed': all(1-limit <= ratio <= 1+limit for ratio in ratios.values()),
            'unchanged_diamond_types_ratios': ratios, 'maximum_reference_drift': limit}


def measure_pair(binary, folder, lane=0, final=False):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    with core_lease(lane) as cpu:
        for attempt in range(1, 4):
            save(folder / 'timing-progress.json', {'attempt': attempt, 'cpu': cpu, 'stage': 'baseline'})
            prefix = f'attempt-{attempt}-'
            baseline = benchmark(STATE / 'baseline-target/release/compare', folder, prefix + 'baseline', 100 if final else 20, cpu)
            save(folder / 'timing-progress.json', {'attempt': attempt, 'cpu': cpu, 'stage': 'candidate'})
            candidate = benchmark(binary, folder, prefix + 'candidate', 100 if final else 20, cpu)
            control = control_check(baseline, candidate, .05 if final else .10)
            result = compare_rows(baseline, candidate)
            result['control_check'] = control
            if final:
                candidate2 = benchmark(binary, folder, prefix + 'candidate-repeat', 100, cpu)
                baseline2 = benchmark(STATE / 'baseline-target/release/compare', folder, prefix + 'baseline-repeat', 100, cpu)
                repeat = compare_rows(baseline2, candidate2)
                repeat['control_check'] = control_check(baseline2, candidate2, .05)
                result['repeat'] = repeat
                control['passed'] &= repeat['control_check']['passed']
            save(folder / f'timing-attempt-{attempt}.json', result)
            if not control['passed']:
                continue
            for suffix in ['baseline', 'candidate'] + (['candidate-repeat', 'baseline-repeat'] if final else []):
                shutil.copy2(folder / (prefix + suffix + '.json'), folder / (suffix + '.json'))
            result.update(timing_cpu=cpu, timing_attempt=attempt, reps=100 if final else 20,
                          timing_control='unchanged diamond-types must remain within 10% on every trace')
            if final:
                result['confirmed_improvement'] = result['S'] > 1.05 and result['repeat']['S'] > 1.05
            save(folder / 'timing-progress.json', {'attempt': attempt, 'cpu': cpu, 'stage': 'complete'})
            return result
    raise TimingUnstable('Unchanged reference timings varied by more than 10%; measurements will be repeated')


def compare_rows(baseline, candidate):
    by_name = {r['trace']: r for r in baseline}
    gains = {r['trace']: by_name[r['trace']]['merge_ms']['strider'] / r['merge_ms']['strider']
             for r in candidate}
    opens = {r['trace']: by_name[r['trace']]['open_ms']['strider'] / r['open_ms']['strider']
             for r in candidate}
    return dict(S=math.exp(statistics.mean(math.log(g) for g in gains.values())),
                per_trace_speedup=gains, reopen_speedup=opens,
                candidate_merge_ms={r['trace']: r['merge_ms']['strider'] for r in candidate},
                baseline_merge_ms={r['trace']: r['merge_ms']['strider'] for r in baseline})


def qualify(task, files, folder, cpu=0, final=False, **kwargs):
    global ORIGINAL
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    if ORIGINAL is None:
        ORIGINAL = json.loads((STATE / 'tasks/eg-strider/original-source.json').read_text())
    project = folder / 'project'
    if not project.exists():
        shutil.copytree(PRISTINE, project, ignore=shutil.ignore_patterns('.git', 'target', 'traces'))
    changes = apply(project, ORIGINAL, files, policy(task))
    target = folder / 'target'
    cargo = folder / 'cargo'
    had_target = target.exists()
    if not target.exists():
        copytree(STATE / 'baseline-target', target)
    if not cargo.exists():
        copytree(STATE / 'cargo-home', cargo)
    with BUILD_LOCK, core_lease(cpu):
        args = container_args(project, target, cargo, folder, cpus=BUILD_CPUS[cpu % len(BUILD_CPUS)])
        # Old, completed timing files imply the earlier build/test calls returned
        # success. Successful stages survive a pool handoff; partial stages rerun.
        old_tests_passed = (folder / 'baseline.log').exists() and had_target
        if not (folder / 'build.success.json').exists() and not old_tests_passed:
            run_logged(args + ['cargo', 'build', '--release', '--locked', '--offline', '-p', 'compare', '-j2'],
                       folder / 'build.log')
        if not (folder / 'tests.success.json').exists() and not old_tests_passed:
            run_logged(args + ['cargo', 'test', '--workspace', '--locked', '--offline', '-j2'],
                       folder / 'tests.log')
    result = measure_pair(target / 'release/compare', folder, cpu, final)
    result.update(status='valid', source_sha256=digest(files), changes=changes,
                  correctness='all unchanged upstream tests and seven diamond-types trace oracles passed',
                  final=final)
    save(folder / 'result.json', result)
    # Retain source, logs and standalone binary; drop redundant dependency copies.
    shutil.copy2(target / 'release/compare', folder / 'candidate-benchmark')
    shutil.rmtree(target)
    shutil.rmtree(cargo)
    return result
